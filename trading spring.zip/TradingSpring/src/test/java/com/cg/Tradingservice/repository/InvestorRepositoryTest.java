package com.cg.Tradingservice.repository;

public class InvestorRepositoryTest {

}
